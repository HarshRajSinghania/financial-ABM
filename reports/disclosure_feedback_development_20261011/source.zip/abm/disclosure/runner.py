"""Archive and inspect reproducible single disclosure-market runs."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import time
import zipfile
from dataclasses import MISSING, asdict, fields
from pathlib import Path
from typing import Any

import numpy as np

from ..manifest import canonical_json_bytes, sha256_file
from ..platform_tuning import disable_power_throttling
from ..tabular import CompanyQLearner
from .config import TRADING_DAYS_PER_YEAR, MarketConfig, load_market_config
from .domain import DomainSpec, load_domain
from .game import DisclosureMarket, DisclosureResult
from .harness import CrossSectionResult
from .learning import action_kinds, load_frozen, save_frozen, table_fingerprint
from .metrics import compute_metrics
from .policy import PolicyRegime, PolicySchedule
from .validate import validate_market


def source_hashes() -> dict[str, str]:
    package = Path(__file__).resolve().parents[1]
    return {path.relative_to(package.parent).as_posix(): sha256_file(path)
            for path in sorted(package.rglob("*.py"))}


def learning_contract(config: MarketConfig, domain: DomainSpec, policy: PolicySchedule) -> dict[str, Any]:
    environment = config.to_dict()
    environment.pop("seed")
    environment.pop("firm_policy")
    return {
        "version": 2, "candidate_fractions": list(config.firm_action_fractions),
        "choice_kinds": action_kinds(2 * len(config.firm_action_fractions) + 1).tolist(),
        "exploration": "uniform_legal_kind_then_uniform_legal_amplitude",
        "feasibility": "positive_value_anchor_after_known_commitments_v1",
        "groups": 6, "config": environment, "domain": domain.to_dict(),
        "policy": asdict(policy), "source_hashes": source_hashes(),
        "python_version": platform.python_version(), "numpy_version": np.__version__,
    }


def run_identity(
    config: MarketConfig, domain: DomainSpec, policy: PolicySchedule, *, learning: dict[str, Any] | None = None,
) -> dict[str, Any]:
    identity = {
        "schema_version": 1,
        "config": config.to_dict(),
        "domain": domain.to_dict(),
        "policy": asdict(policy),
        "source_hashes": source_hashes(),
        "python_version": platform.python_version(),
        "numpy_version": np.__version__,
    }
    if learning is not None:
        identity["learning"] = learning
    return {**identity, "run_id": hashlib.sha256(canonical_json_bytes(identity)).hexdigest()}


def write_json(path: Path, payload: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def save_result(path: Path, result: DisclosureResult) -> None:
    arrays = {item.name: getattr(result, item.name) for item in fields(result)
              if item.name != "market" and getattr(result, item.name) is not None}
    arrays.update({"market_" + item.name: getattr(result.market, item.name) for item in fields(result.market)})
    temporary = path.with_suffix(".tmp.npz")
    np.savez_compressed(temporary, **arrays)
    temporary.replace(path)


def load_result(path: str | Path) -> DisclosureResult:
    with np.load(path, allow_pickle=False) as arrays:
        market = {item.name: arrays["market_" + item.name].copy() for item in fields(CrossSectionResult)}
        market["burn_in_days"] = int(market["burn_in_days"])
        values = {item.name: arrays[item.name].copy() for item in fields(DisclosureResult)
                  if item.name != "market" and (item.name in arrays or item.default is MISSING)}
    return DisclosureResult(market=CrossSectionResult(**market), **values)


def load_policy(path: str | Path, domain: DomainSpec) -> PolicySchedule:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    baseline = PolicyRegime(**payload["baseline"]) if "baseline" in payload else PolicyRegime.baseline(domain)
    intervention = PolicyRegime(**payload["intervention"]) if payload.get("intervention") is not None else None
    return PolicySchedule(baseline, intervention, payload.get("start_day", 0))


def learning_report(
    result: DisclosureResult, config: MarketConfig, learner: CompanyQLearner | None, *, training: bool,
) -> dict[str, Any]:
    visits = np.zeros((6, 81), dtype=np.int64)
    kinds = action_kinds(2 * len(config.firm_action_fractions) + 1)
    legal_visits = np.zeros((6, 81, len(kinds)), dtype=np.int64)
    groups, states = result.learning_groups[1:], result.learning_states[1:]
    np.add.at(visits, (groups.ravel(), states.ravel()), 1)
    for action in range(len(kinds)):
        np.add.at(legal_visits[:, :, action], (groups.ravel(), states.ravel()),
                  result.valid_actions[1:, :, action].ravel().astype(np.int64))
    decisions = int(visits.sum())
    unseen = None if result.unvisited_state is None else int(result.unvisited_state[1:].sum())
    fraction = unseen / decisions if unseen is not None and decisions else None
    undercovered, group_undercovered = [], []
    group_totals = visits.sum(axis=1)
    if learner is not None:
        common = (visits > 0) & (visits >= .01 * decisions)
        for group, state, action in np.argwhere(common[:, :, None] & (legal_visits > 0) & (learner.counts < 20)):
            undercovered.append({"group": int(group), "state": int(state),
                                 "choice_index": int(action), "action": int(kinds[action]),
                                 "count": int(learner.counts[group, state, action])})
        group_common = (visits > 0) & (visits >= .01 * group_totals[:, None])
        for group, state, action in np.argwhere(group_common[:, :, None] & (legal_visits > 0) & (learner.counts < 20)):
            group_undercovered.append({"group": int(group), "state": int(state),
                                       "choice_index": int(action), "action": int(kinds[action]),
                                       "count": int(learner.counts[group, state, action])})
    group_unseen = None
    if result.unvisited_state is not None:
        group_unseen = np.zeros(6, dtype=np.int64)
        np.add.at(group_unseen, groups.ravel(), result.unvisited_state[1:].ravel().astype(np.int64))
    group_reports = []
    for group, total in enumerate(group_totals):
        missing = None if group_unseen is None else int(group_unseen[group])
        share = missing / int(total) if missing is not None and total else None
        status = "not_observed" if not total else (
            "not_applicable" if learner is None or training else (
                "PASS" if share is not None and share <= .05
                and not any(item["group"] == group for item in group_undercovered) else "FAIL"
            )
        )
        group_reports.append({"group": group, "size_class": group % 3, "policy_epoch": group // 3,
                              "decisions": int(total), "unseen_state_decisions": missing,
                              "unseen_state_fraction": share, "status": status})
    global_status = "not_applicable" if learner is None or training else (
        "PASS" if fraction is not None and fraction <= .05 and not undercovered else "FAIL"
    )
    coverage_status = "FAIL" if any(group["status"] == "FAIL" for group in group_reports) else global_status
    period = config.firm_decision_interval
    last = config.trading_days
    last_decision = last // period * period
    ledger = {
        "financing_adjustment": result.financing_value_adjustment,
        "resource_cost": result.applied_resource_cost,
        "fine": result.applied_fine,
        "subsidy": result.applied_subsidy,
    }
    net = ledger["financing_adjustment"] - ledger["resource_cost"] - ledger["fine"] + ledger["subsidy"]
    discount = np.exp(-config.firm_discount_rate * np.arange(last + 1) / TRADING_DAYS_PER_YEAR)
    pending = []
    for decision, firm in np.argwhere(result.action_due_day > last):
        pending.append({"decision_day": int(decision * period), "firm": int(firm),
                        "action": int(result.actions[decision, firm]),
                        "due_day": int(result.action_due_day[decision, firm]),
                        "amount": float(result.amounts[decision, firm])})
    unapplied = {}
    for name, fractions in (("resource_cost", result.cost_fraction), ("fine", result.penalty_fraction),
                            ("subsidy", result.subsidy_fraction)):
        amount = fractions[-1] * result.market.prices[-1] if last_decision == last else np.zeros(config.n_firms)
        unapplied[name] = amount.tolist()
    return {
        "firm_policy": config.firm_policy, "training": training,
        "coverage": {
            "visits": visits.tolist(), "legal_action_visits": legal_visits.tolist(),
            "unseen_state_decisions": unseen, "decisions": decisions, "unseen_state_fraction": fraction,
            "common_state_minimum_action_count": 20, "common_state_share_threshold": .01,
            "common_state_undercovered_actions": undercovered,
            "group_common_state_undercovered_actions": group_undercovered,
            "group_common_state_share_threshold": .01, "maximum_unseen_state_fraction": .05,
            "groups": group_reports, "global_status": global_status, "status": coverage_status,
        },
        "ledger": {
            "scope": "Full observed window; private financing-baseline differences, not causal effects or lifetime profit.",
            "totals_by_firm": {key: value.sum(axis=0).tolist() for key, value in ledger.items()},
            "discounted_net_by_initial_cap": (discount @ net / result.market.prices[0]).tolist(),
            "completed_transitions": int(result.learning_transition.sum()),
        },
        "tail": {
            "last_decision_day": last_decision if last_decision else None,
            "unclosed_decisions": config.n_firms if last_decision else 0,
            "observed_days_of_unclosed_window": last - last_decision if last_decision else 0,
            "unapplied_next_day_commitments": unapplied,
            "pending_projects": pending,
            "outstanding_inflation": result.inflation[-1].tolist(),
        },
    }


def run_and_archive(
    config: MarketConfig,
    domain: DomainSpec,
    output: str | Path,
    policy: PolicySchedule | None = None,
    *,
    purpose: str = "development",
    learner: CompanyQLearner | None = None,
    training: bool = False,
    learning_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Save inputs and source before running; completion requires a result hash."""
    policy = policy or PolicySchedule.constant(domain)
    learning = None
    if config.firm_policy == "q_learning":
        if learner is None or learning_metadata is None:
            raise ValueError("Q-learning requires an explicit learner and frozen learning metadata")
        if learning_metadata.get("contract") != learning_contract(config, domain, policy):
            raise ValueError("learning contract mismatch")
        if (learner.values.shape != (6, 81, 2 * len(config.firm_action_fractions) + 1)
                or learner.counts.shape != learner.values.shape):
            raise ValueError("archived Q-learning requires six size/regime groups")
        if training != (learner.values.flags.writeable and learner.counts.flags.writeable):
            raise ValueError("training requires writable tables; evaluation requires frozen tables")
        if not training and (learner.values.flags.writeable or learner.counts.flags.writeable or learner.epsilon != 0):
            raise ValueError("evaluation requires frozen tables and zero epsilon")
        learning = {"training": training, "metadata": learning_metadata,
                    "initial_table_fingerprint": table_fingerprint(learner), "epsilon": learner.epsilon,
                    "learning_rate": learner.learning_rate, "discount": learner.discount}
    elif learner is not None or training or learning_metadata is not None:
        raise ValueError("learning arguments require the q_learning firm policy")
    destination = Path(output)
    destination.mkdir(parents=True, exist_ok=False)
    identity = run_identity(config, domain, policy, learning=learning)
    manifest = {**identity, "purpose": purpose, "status": "running"}
    write_json(destination / "manifest.json", manifest)
    started = time.perf_counter()
    market = None
    try:
        model_artifacts = []
        if learner is not None:
            save_frozen(destination / "input_model.npz", learner, learning_metadata)
            model_artifacts.append("input_model.npz")
        package_parent = Path(__file__).resolve().parents[2]
        with zipfile.ZipFile(destination / "source.zip", "x", compression=zipfile.ZIP_DEFLATED) as archive:
            for relative in identity["source_hashes"]:
                archive.write(package_parent / relative, relative)
        if source_hashes() != identity["source_hashes"]:
            raise RuntimeError("source changed while archiving the run")
        market = DisclosureMarket(config, domain, policy, learner=learner, training=training)
        result = market.run()
        if learner is not None:
            final_fingerprint = table_fingerprint(learner)
            if not training and final_fingerprint != learning["initial_table_fingerprint"]:
                raise RuntimeError("evaluation changed the frozen learning table")
            save_frozen(destination / "output_model.npz", learner, learning_metadata)
            model_artifacts.append("output_model.npz")
        if config.firm_policy != "npv":
            report = learning_report(result, config, learner, training=training)
            if learner is not None:
                report.update({"initial_table_fingerprint": learning["initial_table_fingerprint"],
                               "final_table_fingerprint": final_fingerprint,
                               "final_transition_count": int(learner.counts.sum())})
            write_json(destination / "learning.json", report)
            model_artifacts.append("learning.json")
        metrics = compute_metrics(result, config, domain)
        validation = validate_market(result.market, config)
        if source_hashes() != identity["source_hashes"]:
            raise RuntimeError("source changed during the run")
        save_result(destination / "result.npz", result)
        write_json(destination / "metrics.json", metrics)
        write_json(destination / "validation.json", validation)
        manifest.update({
            "status": "complete",
            "elapsed_seconds": time.perf_counter() - started,
            "result_fingerprint": result.fingerprint(),
            "artifacts": {name: sha256_file(destination / name)
                          for name in ("source.zip", "result.npz", "metrics.json", "validation.json", *model_artifacts)},
        })
        write_json(destination / "manifest.json", manifest)
    except Exception as error:
        if learner is not None and market is not None:
            try:
                digest = save_frozen(destination / "failed_model.npz", learner, learning_metadata)
                manifest["failed_learning_checkpoint"] = {
                    "path": "failed_model.npz", "sha256": digest,
                    "last_prepared_day": market.signal_day,
                    "table_fingerprint": table_fingerprint(learner),
                    "resumable": False,
                }
            except Exception as checkpoint_error:
                manifest["failed_learning_checkpoint"] = {
                    "error": str(checkpoint_error), "resumable": False,
                    "last_prepared_day": market.signal_day,
                }
        write_json(destination / "manifest.json", {
            **manifest, "status": "failed", "elapsed_seconds": time.perf_counter() - started,
            "error_type": type(error).__name__, "error": str(error),
        })
        raise
    render_run(destination)
    return manifest


def render_run(output: str | Path) -> Path:
    """Rebuild a report from verified archived artifacts, without simulating."""
    destination = Path(output)
    manifest = json.loads((destination / "manifest.json").read_text(encoding="utf-8"))
    if manifest["status"] != "complete":
        raise ValueError("only a completed run can be rendered")
    for name, digest in manifest["artifacts"].items():
        if sha256_file(destination / name) != digest:
            raise ValueError(f"archive hash mismatch: {name}")
    metrics = json.loads((destination / "metrics.json").read_text(encoding="utf-8"))
    validation = json.loads((destination / "validation.json").read_text(encoding="utf-8"))
    lines = [
        "# Disclosure-market run", "", f"Purpose: {manifest['purpose']}",
        f"Domain: {manifest['domain']['name']}", f"Seed: {manifest['config']['seed']}",
        f"Run ID: `{manifest['run_id']}`", f"Result fingerprint: `{manifest['result_fingerprint']}`", "",
        "A completed simulation is not evidence of empirical calibration or a policy ranking.", "",
        "## Metrics", "", "```json", json.dumps(metrics, ensure_ascii=False, indent=2, allow_nan=False), "```", "",
        "## Validation", "", "```json", json.dumps(validation, ensure_ascii=False, indent=2, allow_nan=False), "```", "",
    ]
    if "learning.json" in manifest["artifacts"]:
        report = json.loads((destination / "learning.json").read_text(encoding="utf-8"))
        coverage = report["coverage"]
        lines.extend([
            "## Learning diagnostics", "", f"Firm policy: {report['firm_policy']}",
            f"Training: {report['training']}", f"Coverage status: {coverage['status']}",
            f"Unseen state share: {coverage['unseen_state_fraction']}",
            f"Unclosed decisions: {report['tail']['unclosed_decisions']}",
            "Ledger, coverage counts and pending liabilities: [learning.json](learning.json).", "",
        ])
    report = destination / "report.md"
    report.write_text("\n".join(lines), encoding="utf-8")
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--domain", type=Path)
    parser.add_argument("--policy", type=Path)
    parser.add_argument("--model", type=Path, help="Frozen Q table for evaluation")
    parser.add_argument("--model-sha256")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--render-only", action="store_true")
    args = parser.parse_args(argv)
    if args.render_only:
        print(render_run(args.output))
        return 0
    if args.domain is None:
        parser.error("--domain is required for a new run")
    disable_power_throttling()
    config = load_market_config(args.config) if args.config else MarketConfig()
    domain = load_domain(args.domain)
    policy = load_policy(args.policy, domain) if args.policy else None
    if args.model_sha256 and args.model is None:
        parser.error("--model-sha256 requires --model")
    learner, metadata = load_frozen(args.model, expected_sha256=args.model_sha256) if args.model else (None, None)
    result = run_and_archive(config, domain, args.output, policy, learner=learner, learning_metadata=metadata)
    print(json.dumps({"run_id": result["run_id"], "status": result["status"], "output": str(args.output)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
