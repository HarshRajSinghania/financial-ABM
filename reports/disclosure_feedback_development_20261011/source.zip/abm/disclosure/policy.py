"""Regulatory regime and its schedule.

Instruments act through distinct channels:

* ``audit_probability`` – chance per decision period that a firm's report is
  checked; a detected inflation is removed and fined;
* ``penalty`` – fine per standard deviation of detected inflation, as a
  fraction of market cap;
* ``transparency`` – weight investors put on the true attribute rather than
  the report (``signal = true + (1 - transparency) * inflation``);
* ``subsidy`` – payment per standard deviation of real improvement, as a
  fraction of market cap;
* disclosure error and delay, and dated audit publications, affect the
  public signal separately from the audit and fine instruments.

Audit probability also determines how long inflated reports survive, so
equal probability-times-penalty does not hold either their value or the
discounted fine constant. A transparency comparison keeps audit probability,
penalty and subsidy individually fixed.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from math import isfinite

from .domain import DomainSpec


@dataclass(frozen=True, slots=True)
class PolicyRegime:
    audit_probability: float
    penalty: float
    transparency: float
    subsidy: float
    disclosure_noise_sd: float = 0.0
    disclosure_delay_days: int | None = None
    publish_audit_results: bool = False

    def __post_init__(self) -> None:
        if not 0 <= self.audit_probability <= 1 or not 0 <= self.transparency <= 1:
            raise ValueError("audit_probability and transparency must be in [0, 1]")
        if self.penalty < 0 or self.subsidy < 0:
            raise ValueError("penalty and subsidy must be nonnegative")
        if not isfinite(self.disclosure_noise_sd) or self.disclosure_noise_sd < 0:
            raise ValueError("disclosure_noise_sd must be finite and nonnegative")
        if self.disclosure_delay_days is not None and (
            type(self.disclosure_delay_days) is not int or self.disclosure_delay_days < 0
        ):
            raise ValueError("disclosure_delay_days must be a nonnegative integer or None")
        if type(self.publish_audit_results) is not bool:
            raise ValueError("publish_audit_results must be boolean")

    @classmethod
    def baseline(cls, domain: DomainSpec) -> "PolicyRegime":
        return cls(
            audit_probability=domain.baseline_audit_probability,
            penalty=domain.baseline_penalty,
            transparency=domain.baseline_transparency,
            subsidy=domain.baseline_subsidy,
        )


@dataclass(frozen=True, slots=True)
class PolicySchedule:
    """A baseline regime and one optional switch at ``start_day``."""

    baseline: PolicyRegime
    intervention: PolicyRegime | None = None
    start_day: int = 0

    def __post_init__(self) -> None:
        if self.start_day < 0:
            raise ValueError("start_day must be nonnegative")

    def at(self, day: int) -> PolicyRegime:
        if self.intervention is not None and day >= self.start_day:
            return self.intervention
        return self.baseline

    @classmethod
    def constant(cls, domain: DomainSpec) -> "PolicySchedule":
        return cls(baseline=PolicyRegime.baseline(domain))

    def with_intervention(self, start_day: int, **changes: float | bool | None) -> "PolicySchedule":
        return replace(self, intervention=replace(self.baseline, **changes), start_day=start_day)

    def with_information_intervention(
        self, start_day: int, *, transparency: float | None = None,
        disclosure_noise_sd: float | None = None, disclosure_delay_days: int | None = None,
        publish_audit_results: bool | None = None,
    ) -> "PolicySchedule":
        """Change information instruments, retaining audit, fine and subsidy."""
        changes = {name: value for name, value in {
            "transparency": transparency, "disclosure_noise_sd": disclosure_noise_sd,
            "disclosure_delay_days": disclosure_delay_days, "publish_audit_results": publish_audit_results,
        }.items() if value is not None}
        return self.with_intervention(start_day, **changes)
