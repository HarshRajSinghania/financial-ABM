"""Expected financing-fee cash flows for a fixed external exposure.

The horizon limits prospective fee savings. A false report's eventual fine
remains a liability beyond that horizon. Quotes observed on day t can first
affect a contract repriced on day t + 1; audits follow that day's trading.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .config import TRADING_DAYS_PER_YEAR


def financing_discount_factors(
    discount_rate: NDArray[np.float64], *, decision_day: int, horizon_days: int,
    repricing_interval: int, period_days: int, implementation_delay: int,
    disclosure_delay: int, audit_probability: float,
) -> tuple[NDArray[np.float64], NDArray[np.float64], NDArray[np.float64]]:
    """Return real/wash annuities and the expected discounted fine factor.

Rates and future quote responses are locally held fixed. These are firms'
conditional forecasts, not an assertion of a permanent equilibrium premium.
    """
    times = np.arange(1, horizon_days + 1)
    calendar = decision_day + times
    last_reprice = calendar // repricing_interval * repricing_interval
    quoted_day = last_reprice - 1
    real_due = decision_day + max(1, implementation_delay)
    wash_due = decision_day + max(1, disclosure_delay)
    real_visible = quoted_day >= real_due
    wash_visible = quoted_day >= wash_due
    first_audit = ((wash_due + period_days - 1) // period_days) * period_days
    # A quote precedes the audit on its own day, so only earlier audits
    # remove the signal used at a contract's most recent repricing.
    audits = np.maximum(0, (quoted_day - 1 - first_audit) // period_days + 1)
    survival = np.power(1.0 - audit_probability, audits) * wash_visible
    discount = np.exp(-times[:, None] * np.asarray(discount_rate)[None, :] / TRADING_DAYS_PER_YEAR)
    real = real_visible @ discount / TRADING_DAYS_PER_YEAR
    wash = survival @ discount / TRADING_DAYS_PER_YEAR
    if audit_probability == 0:
        fine = np.zeros_like(discount_rate)
    else:
        first_discount = np.exp(-discount_rate * (first_audit - decision_day) / TRADING_DAYS_PER_YEAR)
        repeat_discount = np.exp(-discount_rate * period_days / TRADING_DAYS_PER_YEAR)
        fine = audit_probability * first_discount / (1.0 - (1.0 - audit_probability) * repeat_discount)
    return real, wash, fine


def financing_signal_factors(
    discount_rate: NDArray[np.float64], *, decision_day: int, horizon_days: int,
    repricing_interval: int, period_days: int, implementation_delay: int,
    disclosure_delay: int, audit_probability: float, transparency: float,
    publish_audit_results: bool = False, published_now: NDArray[np.bool_] | None = None,
) -> tuple[NDArray[np.float64], NDArray[np.float64], NDArray[np.float64], NDArray[np.float64]]:
    """Return low/high real-signal annuities, wash survival and the fine factor.

    Remaining report capacity is locally fixed. Audits remove the old
    inflation displaced by a real action. Avoided fines on that old stock
    are excluded for both publication regimes. A published snapshot lasts
    one decision period and contains an action only if it was implemented
    by the snapshot's observation date. ``published_now`` is the firm's
    known, just-completed audit; future checks remain random.
    """
    real, wash, fine = financing_discount_factors(
        discount_rate, decision_day=decision_day, horizon_days=horizon_days,
        repricing_interval=repricing_interval, period_days=period_days,
        implementation_delay=implementation_delay, disclosure_delay=disclosure_delay,
        audit_probability=audit_probability,
    )
    times = np.arange(1, horizon_days + 1)
    quoted_day = (decision_day + times) // repricing_interval * repricing_interval - 1
    real_due = decision_day + max(1, implementation_delay)
    wash_due = decision_day + max(1, disclosure_delay)
    real_visible = quoted_day >= real_due
    checks = np.maximum(0, (quoted_day - 1) // period_days - decision_day // period_days)
    old_survival = np.power(1.0 - audit_probability, checks)
    discount = np.exp(-times[:, None] * np.asarray(discount_rate)[None, :] / TRADING_DAYS_PER_YEAR)
    if not publish_audit_results:
        displaced = real - (1.0 - transparency) * ((real_visible * old_survival) @ discount / TRADING_DAYS_PER_YEAR)
        return real, displaced, wash, fine

    known = np.zeros(np.asarray(discount_rate).size, dtype=bool) if published_now is None else np.asarray(published_now, dtype=bool)
    latest_audit = (quoted_day - 1) // period_days * period_days
    current = latest_audit == decision_day
    certificate = np.where((latest_audit > decision_day)[:, None], audit_probability,
                           np.where(current[:, None], known[None, :], 0.0))
    visible = real_visible[:, None]
    real_signal = visible * (1.0 - certificate) + certificate * (latest_audit >= real_due)[:, None]
    # Surviving old inflation and a future published check are mutually
    # exclusive. A known pre-action certificate can coexist with it.
    unverified_old = old_survival[:, None] * np.where(current[:, None], ~known[None, :], 1.0)
    displaced_signal = real_signal - (1.0 - transparency) * visible * unverified_old
    first_audit = ((wash_due + period_days - 1) // period_days) * period_days
    wash_checks = np.maximum(0, (quoted_day - 1 - first_audit) // period_days + 1)
    wash_survival = np.power(1.0 - audit_probability, wash_checks)[:, None]
    # A pre-disclosure certificate can hide a surviving new report. After
    # disclosure, the selected check already removes that report.
    wash_signal = (quoted_day >= wash_due)[:, None] * (
        wash_survival - certificate * (latest_audit < wash_due)[:, None]
    )
    return (np.sum(real_signal * discount, axis=0) / TRADING_DAYS_PER_YEAR,
            np.sum(displaced_signal * discount, axis=0) / TRADING_DAYS_PER_YEAR,
            np.sum(wash_signal * discount, axis=0) / TRADING_DAYS_PER_YEAR, fine)
