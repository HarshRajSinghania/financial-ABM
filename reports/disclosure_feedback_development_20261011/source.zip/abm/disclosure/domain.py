"""Domain specification: what the disclosed attribute is and what it costs.

The market core works in *goodness* units: the attribute standardized by its
initial cross-sectional distribution and signed so that higher is better.
A domain maps raw scores (a rating, an intensity, ...) to goodness and supplies costs, delays and the baseline regulatory regime. All
costs are fractions of the firm's market capitalisation: quadratic resource
cost coefficients are per squared standard deviation of goodness, while
penalties and subsidies are per standard deviation. Direct size differences
in resource costs enter through ``size_cost_multipliers``.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any, Mapping

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class DomainSpec:
    name: str
    attribute_label: str
    unit: str
    # +1 when a higher raw score is better (a rating), -1 when lower is
    # better (an intensity).
    direction: int
    initial_mean: float
    initial_sd: float
    raw_lower: float
    raw_upper: float
    # Goodness lost per year without effort (standards tighten, assets age).
    natural_decay: float
    # Cost of one standard deviation of real improvement, as a fraction of
    # market cap, for a mid-size firm: median and log dispersion across firms.
    real_cost_scale: float
    real_cost_log_sd: float
    size_cost_multipliers: tuple[float, float, float]
    # Marginal cost rises with the level already reached, cost * exp(eta * g);
    # without it a constant benefit makes firms improve every period forever.
    cost_level_elasticity: float
    # Most a firm can change its true attribute or its report in one decision
    # period, in standard deviations (capacity, not cost, binds beyond it).
    max_change_per_period: float
    # Cost of inflating the report by one standard deviation, relative to the
    # real cost.
    wash_cost_ratio: float
    implementation_delay_days: int
    disclosure_delay_days: int
    baseline_audit_probability: float
    baseline_penalty: float
    baseline_transparency: float
    baseline_subsidy: float
    action_labels: dict[str, str] = field(default_factory=dict)
    initial_empirical_distribution: tuple[tuple[float, int], ...] = ()

    def __post_init__(self) -> None:
        if not self.name or not self.attribute_label:
            raise ValueError("domain name and attribute label are required")
        if self.direction not in (1, -1):
            raise ValueError("direction must be +1 or -1")
        for item in fields(self):
            value = getattr(self, item.name)
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError(f"{item.name} must be finite")
        if self.initial_sd <= 0 or self.raw_lower >= self.raw_upper:
            raise ValueError("initial_sd must be positive and raw bounds ordered")
        if not self.raw_lower <= self.initial_mean <= self.raw_upper:
            raise ValueError("initial_mean must lie within the raw bounds")
        for name in ("natural_decay", "real_cost_log_sd", "cost_level_elasticity",
                     "baseline_penalty", "baseline_subsidy"):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} must be nonnegative")
        for name in ("real_cost_scale", "wash_cost_ratio", "max_change_per_period"):
            if getattr(self, name) <= 0:
                raise ValueError(f"{name} must be positive")
        if len(self.size_cost_multipliers) != 3 or min(self.size_cost_multipliers) <= 0:
            raise ValueError("size_cost_multipliers needs three positive values (large, mid, small)")
        for name in ("implementation_delay_days", "disclosure_delay_days"):
            value = getattr(self, name)
            if type(value) is not int or value < 0:
                raise ValueError(f"{name} must be a nonnegative integer")
        for name in ("baseline_audit_probability", "baseline_transparency"):
            if not 0 <= getattr(self, name) <= 1:
                raise ValueError(f"{name} must be in [0, 1]")
        unknown = set(self.action_labels) - {"improve", "wash", "maintain"}
        if unknown:
            raise ValueError(f"unknown action labels: {sorted(unknown)}")
        if self.initial_empirical_distribution:
            support, counts = zip(*self.initial_empirical_distribution)
            if any(type(count) is not int or count <= 0 for count in counts):
                raise ValueError("empirical frequencies must be positive integers")
            if len(set(support)) != len(support) or any(
                not math.isfinite(value) or not self.raw_lower <= value <= self.raw_upper
                for value in support
            ):
                raise ValueError("empirical support must be unique, finite and within raw bounds")
            mean = float(np.average(support, weights=counts))
            sd = float(np.sqrt(np.average((np.asarray(support) - mean)**2, weights=counts)))
            if not math.isclose(mean, self.initial_mean, rel_tol=1e-10, abs_tol=1e-12) or not math.isclose(
                sd, self.initial_sd, rel_tol=1e-10, abs_tol=1e-12
            ):
                raise ValueError("initial_mean and initial_sd must match the empirical population moments")

    @property
    def goodness_bounds(self) -> tuple[float, float]:
        ends = sorted(self.to_goodness(np.array([self.raw_lower, self.raw_upper])))
        return float(ends[0]), float(ends[1])

    def to_goodness(self, raw: FloatArray) -> FloatArray:
        return self.direction * (np.asarray(raw, dtype=np.float64) - self.initial_mean) / self.initial_sd

    def to_raw(self, goodness: FloatArray) -> FloatArray:
        return self.initial_mean + self.direction * self.initial_sd * np.asarray(goodness, dtype=np.float64)

    def label(self, action: str) -> str:
        return self.action_labels.get(action, action)

    def to_dict(self) -> dict[str, Any]:
        return {
            item.name: list(getattr(self, item.name)) if item.name == "size_cost_multipliers"
            else [list(pair) for pair in self.initial_empirical_distribution] if item.name == "initial_empirical_distribution"
            else getattr(self, item.name)
            for item in fields(self)
            if item.name != "initial_empirical_distribution" or self.initial_empirical_distribution
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "DomainSpec":
        known = {item.name for item in fields(cls)}
        unknown = set(payload) - known
        if unknown:
            raise ValueError(f"unknown domain keys: {sorted(unknown)}")
        values = {key: value for key, value in payload.items() if not key.startswith("_")}
        values["size_cost_multipliers"] = tuple(float(value) for value in values["size_cost_multipliers"])
        if "initial_empirical_distribution" in values:
            values["initial_empirical_distribution"] = tuple(
                (float(value), count) for value, count in values["initial_empirical_distribution"]
            )
        return cls(**values)


def load_domain(path: str | Path) -> DomainSpec:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise TypeError("domain file root must be a JSON object")
    return DomainSpec.from_dict({key: value for key, value in payload.items() if not key.startswith("_")})
