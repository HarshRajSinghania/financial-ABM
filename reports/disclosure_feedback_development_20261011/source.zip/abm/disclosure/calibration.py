"""Build an empirical observed-proxy domain from an explicitly selected CSV cohort."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from collections import Counter
from dataclasses import fields, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .domain import DomainSpec, load_domain

STATE_ASSUMPTION = (
    "The CSV measures an observed proxy. Assigning independent empirical draws to the simulated "
    "true state with zero initial inflation is a modeling assumption, not an identified "
    "decomposition of real capability and misrepresentation."
)


def file_identity(path: Path) -> dict[str, Any]:
    return {"path": path.as_posix(), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def calibrate_csv(
    source_csv: str | Path,
    template: DomainSpec,
    *,
    value_column: str,
    year_column: str | None,
    year: str | None,
    raw_lower: float,
    raw_upper: float,
    direction: int,
    unit: str,
    name: str,
    attribute_label: str,
    source_url: str | None = None,
    raw_source: str | Path | None = None,
) -> tuple[DomainSpec, dict[str, Any]]:
    if (year_column is None) != (year is None):
        raise ValueError("year_column and year must be specified together, or both explicitly None")
    if not unit.strip():
        raise ValueError("unit must be explicitly specified")
    if direction not in (-1, 1):
        raise ValueError("direction must be +1 or -1")
    if not math.isfinite(raw_lower) or not math.isfinite(raw_upper) or raw_lower >= raw_upper:
        raise ValueError("theoretical raw bounds must be finite and ordered")
    source_csv = Path(source_csv)
    values = []
    total_rows = filtered_out = missing_values = missing_years = 0
    with source_csv.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames or []
        if len(set(headers)) != len(headers) or not headers or any(not field.strip() for field in headers):
            raise ValueError("CSV headers must be present, nonblank and unique")
        required = {value_column} | ({year_column} if year_column is not None else set())
        if required - set(headers):
            raise ValueError(f"missing explicitly selected CSV columns: {sorted(required - set(headers))}")
        for row_number, row in enumerate(reader, start=2):
            total_rows += 1
            if None in row or any(value is None for value in row.values()):
                raise ValueError(f"malformed CSV record {row_number}")
            if year_column is not None:
                if not row[year_column].strip():
                    missing_years += 1
                if row[year_column].strip() != str(year):
                    filtered_out += 1
                    continue
            text = row[value_column].strip()
            if not text:
                missing_values += 1
                continue
            try:
                value = float(text)
            except ValueError as error:
                raise ValueError(f"nonnumeric proxy at CSV record {row_number}: {text!r}") from error
            if not math.isfinite(value) or not raw_lower <= value <= raw_upper:
                raise ValueError(f"proxy outside finite theoretical bounds at CSV record {row_number}: {text!r}")
            values.append(value)
    if len(values) < 2 or len(set(values)) < 2:
        raise ValueError("selected cohort needs at least two distinct finite proxy values")
    distribution = tuple(sorted(Counter(values).items()))
    mean, sd = statistics.fmean(values), statistics.pstdev(values)
    domain = replace(
        template, name=name, attribute_label=attribute_label, unit=unit, direction=direction,
        raw_lower=raw_lower, raw_upper=raw_upper, initial_mean=mean, initial_sd=sd,
        initial_empirical_distribution=distribution, action_labels={},
    )
    identified = {"name", "attribute_label", "unit", "direction", "raw_lower", "raw_upper",
                  "initial_mean", "initial_sd", "initial_empirical_distribution", "action_labels"}
    assumed = {item.name: getattr(domain, item.name) for item in fields(domain) if item.name not in identified}
    report = {
        "status": "observed_proxy_initial_distribution_only",
        "source_csv": file_identity(source_csv),
        "upstream_raw_file": file_identity(Path(raw_source)) if raw_source is not None else None,
        "source_url": source_url,
        "selection": {"value_column": value_column, "year_column": year_column, "year": year,
                      "year_match": "trimmed literal equality" if year_column is not None else "all rows",
                      "input_rows": total_rows, "filtered_out_rows": filtered_out,
                      "missing_year_rows": missing_years, "selected_blank_value_rows": missing_values,
                      "included_rows": len(values), "missing_policy": "exclude blank values; reject nonnumeric, nonfinite and out-of-bounds values"},
        "mapping": {"direction": direction, "unit": unit, "raw_lower": raw_lower, "raw_upper": raw_upper,
                    "fixed_initial_mean": mean, "fixed_initial_sd": sd, "sd_convention": "population, ddof=0"},
        "sample": {"n": len(values), "unique_values": len(distribution), "min": min(values), "max": max(values),
                   "mean": mean, "population_sd": sd, "median": statistics.median(values),
                   "zero_mass": values.count(0.0) / len(values),
                   "lower_bound_mass": values.count(raw_lower) / len(values),
                   "upper_bound_mass": values.count(raw_upper) / len(values)},
        "initialization": {"method": "empirical discrete sampling with replacement",
                           "raw_value_counts": [list(pair) for pair in distribution],
                           "state_assumption": STATE_ASSUMPTION,
                           "joint_distribution": "No company identity, size-attribute correlation, measurement-error process or longitudinal dynamics is fitted."},
        "assumption_template": template.name,
        "unidentified_domain_parameters": list(assumed),
        "assumed_domain_parameters": assumed,
        "other_unidentified_mechanisms": ["latent capability and initial inflation", "investor preferences and learning",
                                          "price impact and financing transmission", "policy causal effects"],
    }
    return domain, report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--value-column", required=True)
    parser.add_argument("--year-column")
    selection = parser.add_mutually_exclusive_group(required=True)
    selection.add_argument("--year")
    selection.add_argument("--all-rows", action="store_true")
    parser.add_argument("--raw-lower", type=float, required=True)
    parser.add_argument("--raw-upper", type=float, required=True)
    parser.add_argument("--direction", type=int, choices=(-1, 1), required=True)
    parser.add_argument("--unit", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--attribute-label", required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--source-url")
    parser.add_argument("--raw-source", type=Path)
    parser.add_argument("--output-domain", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args(argv)
    if (args.year is not None and args.year_column is None) or (args.all_rows and args.year_column is not None):
        parser.error("use --year with --year-column, or --all-rows without a year column")
    if args.output_domain.resolve() == args.report.resolve():
        parser.error("domain and report outputs must be different files")
    if args.output_domain.exists() or args.report.exists():
        parser.error("output files already exist; choose new paths")
    try:
        domain, report = calibrate_csv(
            args.csv, load_domain(args.template), value_column=args.value_column,
            year_column=args.year_column, year=args.year, raw_lower=args.raw_lower, raw_upper=args.raw_upper,
            direction=args.direction, unit=args.unit, name=args.name, attribute_label=args.attribute_label,
            source_url=args.source_url, raw_source=args.raw_source,
        )
    except (OSError, TypeError, ValueError) as error:
        parser.error(str(error))
    report["template_file"] = file_identity(args.template)
    payload = {
        "_note": STATE_ASSUMPTION + " Only the initial proxy distribution is fitted. Costs, decay, delays and policy parameters are inherited assumptions, not empirical estimates.",
        "_sources": [args.source_url] if args.source_url else [],
        "_calibration": {key: report[key] for key in ("status", "source_csv", "upstream_raw_file", "selection", "sample", "template_file", "unidentified_domain_parameters")},
        **domain.to_dict(),
    }
    args.output_domain.parent.mkdir(parents=True, exist_ok=True)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    with args.output_domain.open("x", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    report["generated_utc"] = datetime.now(timezone.utc).isoformat()
    report["output_domain"] = file_identity(args.output_domain)
    report["calibration_code"] = file_identity(Path(__file__))
    with args.report.open("x", encoding="utf-8") as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
    print(json.dumps({"domain": str(args.output_domain), "report": str(args.report), "included_rows": report["sample"]["n"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
